Para rodar o backend

node src/index.js